
MODDIR=${0%/*}

bootLogPath=$MODDIR/freezeitBoot.log


grep_prop() {
  local REGEX="s/^$1=//p"
  shift
  local FILES=$@
  [ -z "$FILES" ] && FILES='/system/build.prop'
  cat $FILES 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1
}

mountFreezerV2() {
    for modDir in cgroupfix cgroupv1 cgroup_freezer_mount; do
        fullDir="/data/adb/modules/$modDir"
        if [[ -e $fullDir ]] && [[ ! -e $fullDir/disable ]]; then
            echo "[$(date "+%Y-%m-%d %H:%M:%S")] 由[$modDir][$(grep_prop name $fullDir/module.prop)]模块主导挂载FreezerV2" >>$bootLogPath
            echo "[$(date "+%Y-%m-%d %H:%M:%S")] 冻它已退出挂载操作" >>$bootLogPath
            return
        fi
    done

    if [ -e /sys/fs/cgroup/uid_1000/cgroup.freeze ]; then
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 已支持FreezerV2(uid)" >>$bootLogPath
        return
    fi

    if [ -e /sys/fs/cgroup/frozen/cgroup.freeze ]; then
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 已支持FreezerV2(frozen)" >>$bootLogPath
        return
    fi

    echo "[$(date "+%Y-%m-%d %H:%M:%S")] 开始卸载系统原生 cgroup/2" >>$bootLogPath

    if [ -e /sys/fs/cgroup/frozen/cgroup.freeze ]; then
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 已支持FreezerV2(frozen)" >>$bootLogPath
        return
    fi

    umount /sys/fs/cgroup/freezer >/dev/null
    umount /sys/fs/cgroup >>$bootLogPath 2>&1

    umount /dev/op_cgroup/freezer >/dev/null 2>&1
    umount /dev/op_cgroup >/dev/null 2>&1
    umount /dev/freezer >/dev/null 2>&1

    umount /dev/cg2_bpf/unfrozen >/dev/null 2>&1
    umount /dev/cg2_bpf/frozen >/dev/null 2>&1
    umount /dev/cg2_bpf >/dev/null 2>&1

    mount -t cgroup2 -o nosuid,nodev,noexec none /sys/fs/cgroup >>$bootLogPath 2>&1
    echo "[$(date "+%Y-%m-%d %H:%M:%S")] 挂载 cgroup2" >>$bootLogPath
    sleep 1

    if [ -e /sys/fs/cgroup/uid_1000/cgroup.freeze ]; then
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 已挂载 FreezerV2(uid)" >>$bootLogPath
    else
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 不支持 FreezerV2(uid)" >>$bootLogPath
    fi

    mkdir -p /sys/fs/cgroup/frozen
    mkdir -p /sys/fs/cgroup/unfrozen
    sleep 1

    if [[ -e /sys/fs/cgroup/frozen/cgroup.freeze ]] && [[ -e /sys/fs/cgroup/unfrozen/cgroup.freeze ]]; then
        echo 1 >/sys/fs/cgroup/frozen/cgroup.freeze
        echo 0 >/sys/fs/cgroup/unfrozen/cgroup.freeze
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 已挂载 FreezerV2(frozen)" >>$bootLogPath
    else
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 不支持 FreezerV2(frozen)" >>$bootLogPath
    fi
}

echo "[$(date "+%Y-%m-%d %H:%M:%S")] 进入Linux" >$bootLogPath

if [[ -e $MODDIR/mount_v2 ]] && [[ $(cat $MODDIR/mount_v2) -eq "1" ]]; then
    androidVersion=$(getprop ro.build.version.release)
    if [[ $androidVersion -ge 11 ]] && [[ $androidVersion -le 13 ]]; then
        mountFreezerV2
    else
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 仅支持[Android 11-13]挂载FreezerV2, 当前[Android $androidVersion]" >>$bootLogPath
    fi
fi
