$BOOTMODE || abort "
!!! ONLY be installed on Magisk or KernelSU. 
!!! 仅支持在 Magisk 或 KernelSU 下安装。"

[ $API -ge 29 ] || abort "
!!! ONLY support Android 10 (SDK29) or above. 
!!! 仅支持 安卓10 或以上。"

if [ $ARCH == "arm64" ]; then
	echo "- 设备架构 ARM64"
	mv -f $MODPATH/bin/freezeitARM64 $MODPATH/bin/freezeit
	rm -f $MODPATH/bin/freezeitX64
elif [ $ARCH == "x64" ]; then
	echo "- 设备架构 X64"
	mv -f $MODPATH/bin/freezeitX64 $MODPATH/bin/freezeit
	rm -f $MODPATH/bin/freezeitARM64
else
	abort "
!!! ONLY support ARM64 and X64
!!! 仅支持 ARM64 和 X64"
fi

chmod +x $MODPATH/bin/freezeit

output=$(pm uninstall cn.myflv.android.noanr)
if [ $output == "Success" ]; then
	echo "- !!! ⚠️功能冲突, 已卸载 [NoANR]"
fi

output=$(pm list packages cn.myflv.android.noactive)
if [ ${#output} -gt 2 ]; then
	echo "- !!! ⚠️检测到 [NoActive](myflavor), 请到 LSPosed 手动取消勾选"
fi

output=$(pm list packages com.github.uissd.miller)
if [ ${#output} -gt 2 ]; then
	echo "- !!! ⚠️检测到 [Miller](UISSD), 请到 LSPosed 手动取消勾选"
fi

output=$(pm list packages com.github.f19f.milletts)
if [ ${#output} -gt 2 ]; then
	echo "- !!! ⚠️检测到 [MiTombstone](f19没有新欢), 请到 LSPosed 手动取消勾选"
fi

output=$(pm list packages com.ff19.mitlite)
if [ ${#output} -gt 2 ]; then
	echo "- !!! ⚠️检测到 [Mitlite](f19没有新欢), 请到 LSPosed 手动取消勾选"
fi

if [ -e "/data/adb/modules/mubei" ]; then
	echo "- !!! ⚠️已禁用 [自动墓碑后台](奋斗的小青年), 请到 LSPosed 取消勾选相关应用"
	touch /data/adb/modules/mubei/disable
fi

if [ -e "/data/adb/modules/Hc_tombstone" ]; then
	echo "- !!! ⚠️已禁用 [新内核墓碑](时雨星空/火柴)"
	touch /data/adb/modules/Hc_tombstone/disable
fi

output=$(pm uninstall com.jark006.freezeit)
if [ $output == "Success" ]; then
	echo "- !!! ⚠️ 冻它APP已更换新包名, 旧版APP已卸载"
	echo "- !!! ⚠️ 安装完毕后, 请到 LSPosed 重新启用冻它"
	echo ""
fi

if [ $KSU ]; then
	ORG_appcfg="/data/adb/ksu/modules/freezeit/appcfg.txt"
	ORG_applabel="/data/adb/ksu/modules/freezeit/applabel.txt"
	ORG_settings="/data/adb/ksu/modules/freezeit/settings.db"

	if [ -e "/data/adb/modules/freezeit" ]; then
		echo "- !!! ⚠️ 当前为[KernelSU]环境, 已禁用[Magisk]版冻它模块"
		touch /data/adb/modules/freezeit/disable
	fi
else
	ORG_appcfg="/data/adb/modules/freezeit/appcfg.txt"
	ORG_applabel="/data/adb/modules/freezeit/applabel.txt"
	ORG_settings="/data/adb/modules/freezeit/settings.db"

	if [ -e "/data/adb/ksu/modules/freezeit" ]; then
		echo "- !!! ⚠️ 当前为[Magisk]环境, 已禁用[KernelSU]版冻它模块"
		touch /data/adb/ksu/modules/freezeit/disable
	fi
fi

for path in $ORG_appcfg $ORG_applabel $ORG_settings; do
	if [ -e $path ]; then
		cp -f $path $MODPATH
	fi
done

output=$(pm list packages io.github.jark006.freezeit)
if [ ${#output} -lt 2 ]; then
	echo "- !!! ⚠️ 首次安装, 安装完毕后, 请到LSPosed管理器启用冻它, 然后再重启"
fi

module_version="$(grep_prop version $MODPATH/module.prop)"
echo "- 正在安装 $module_version"

apkPath=$TMPDIR/freezeit.apk
mv -f $(ls $MODPATH/freezeit*.apk) $apkPath
chmod 666 $apkPath

echo "- 冻它APP 正在安装..."
output=$(pm install -r -f $apkPath)
if [ $output == "Success" ]; then
	echo "- 冻它APP 安装成功"
else
	echo "- 冻它APP 安装失败, 原因: [$output] 重新尝试安装..."
	sleep 2
	output=$(pm install -r -f $apkPath)
	if [ $output == "Success" ]; then
		echo "- 冻它APP 安装成功"
	else
		apkPathSdcard="/sdcard/freezeit_${module_version}.apk"
		cp -f $apkPath $apkPathSdcard
		echo "!!! *************** !!!"
		echo "  冻它APP 依旧安装失败, 原因: [$output]"
		echo "  请手动安装 [ $apkPathSdcard ]"
		echo "!!! *************** !!!"
	fi
fi
rm -rf $apkPath

# 修改部分lmk参数, 仅限 Android 14 U SDK34 及以下
androidVersion=$(getprop ro.build.version.release)
if [ $API -le 34 ]; then
	echo "
ro.lmk.swap_free_low_percentage=10
ro.lmk.psi_partial_stall_ms=200
ro.lmk.psi_complete_stall_ms=700
" >>$MODPATH/system.prop
fi

# 仅限 MIUI 13~15
MIUI_VersionCode=$(getprop ro.miui.ui.version.code)
if [ $MIUI_VersionCode -ge 13 -a $MIUI_VersionCode -le 15 ]; then
	echo "
# 禁用 Millet
persist.sys.gz.enable=false
persist.sys.millet.handshake=false
persist.sys.powmillet.enable=false
persist.sys.brightmillet.enable=false

# 缓解杀后台 (源自酷安 @moonheart)
persist.sys.mms.compact_enable=true
persist.sys.mms.bg_apps_limit=256
persist.sys.spc.enabled=false
persist.sys.spc.extra_free_enable=false
persist.sys.spc.screenoff_kill_enable=false
" >>$MODPATH/system.prop
fi

echo ""
echo "- 安装完毕, 重启生效"
echo "- 若出现异常日志, 请反馈给作者, 谢谢"
echo "- [ /sdcard/Android/freezeit_crash_log.txt ]"
echo ""
