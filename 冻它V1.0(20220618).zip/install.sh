##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=true

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod
print_modname() {
	return
}

##########################################################################################
# Replace list
##########################################################################################
# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
SKIPUNZIP=0
REPLACE="
"
##########################################################################################
# Install
##########################################################################################
on_install() {
	$BOOTMODE || abort "
	!!! ONLY be installed on magisk. 
	!!! 仅支持在 Magisk 下安装, Recovery的老哥别手抖。
	"
    [ $API -ge 26 ] || abort "
	!!! ONLY support Android8.0 (SDK26) or above. 
	!!! 仅支持 安卓8.0 及以上版本，考虑一下换机吧。
	"
    [ $MAGISK_VER_CODE -ge 23000 ] || abort "
	!!! ONLY support Magisk V23.0 or above. 
	!!! 仅支持 Magisk V23.0 及以上版本。
	"
    [ $ARCH == "arm64" ] || abort "
	!!! ONLY support ARM64 platform. 
	!!! 仅支持 ARM 64位 平台。
	"
	
	unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2

	module_name="$(grep_prop name $MODPATH/module.prop)"
	module_version="$(grep_prop version $MODPATH/module.prop)"
	module_author="$(grep_prop author $MODPATH/module.prop)"

	module_logPath="$(grep_prop logPath $MODPATH/module.prop)"
	module_packageListPath="$(grep_prop packageListPath $MODPATH/module.prop)"

	echo -e "\n********************************************"
	echo "  模块:     $module_name"
	echo "  版本:     $module_version"
	echo "  作者:     $module_author"
	echo "  日志文件: $module_logPath"
	echo "  配置文件: $module_packageListPath"
	echo -e "********************************************\n"
	cat $MODPATH/changelog.txt
	echo -e "\n********************************************\n"

	# TODO pm install
	# cp $MODPATH/app.apk $TMPDIR
	# apkPath = "$TMPDIR/app.apk"
	# chmod 777 apkPath
	# echo "- 开始安装 冻它APP..."
	# # apkSize=`wc -c "$apkPath" | awk '{print $1}'`
	# apkSize=`ls -l "$apkPath" | awk '{print $5}'`
	# cat $apkPath | pm install -S $apkSize -r -g
	# if [[ $? = 0 ]]; then
	# 	echo "- 安装成功"
	# else
	# 	# abort "- 安装失败"
	# 	echo -e "- !!!\n- !!!安装失败, 可能APP只是占位用的, 待更新\n- !!!"
	# fi
	# rm -f $apkPath
}

##########################################################################################
# Permissions
##########################################################################################
set_permissions() {
	# The following is default permissions, DO NOT remove
	set_perm_recursive $MODPATH  0  0  0755  0644
	set_perm_recursive $MODPATH/bin 0 0 0755 0755
	echo "- 安装完毕，重启生效"
}

