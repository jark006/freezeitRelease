#!/system/bin/sh
MODDIR=${0%/*}

bootTimestamp=$(date "+%s")
bootLogPath=$MODDIR/freezeitBoot.log

# 第一次开机超时 10分钟 (600秒) 未进入桌面会做一个标记，然后直接退出。
# 第二次开机超时 10分钟 (600秒) 则禁用全部模块，然后重启。
handle_sec_disable_all() {
    bootTimeCnt=$(($(date "+%s") - bootTimestamp))
    echo "[$(date "+%Y-%m-%d %H:%M:%S")] $bootTimeCnt $*" >>$bootLogPath
    if [ $bootTimeCnt -gt 300 ]; then
        if [ -e $MODDIR/fail_once ]; then
            ls "/data/adb/modules" | while read i; do
                touch "/data/adb/modules/$i/disable" &>/dev/null
            done
            echo "[$(date "+%Y-%m-%d %H:%M:%S")] $bootTimeCnt 开机超过10分钟未进入桌面(连续第二次), 已禁用全部模块,即将重启" >>$bootLogPath
            sleep 5
            reboot
            sleep 60
            exit
        else
            touch $MODDIR/fail_once &>/dev/null
            echo "[$(date "+%Y-%m-%d %H:%M:%S")] $bootTimeCnt 开机超过10分钟未进入桌面(第一次), 已记录本次异常, 模块已退出" >>$bootLogPath
            exit
        fi
    fi
}

# 开机超时 10分钟 (600秒) 未进入桌面则禁用自身，然后退出
handle_sec() {
    bootTimeCnt=$(($(date "+%s") - bootTimestamp))
    echo "[$(date "+%Y-%m-%d %H:%M:%S")] $bootTimeCnt $*" >>$bootLogPath
    if [ $bootTimeCnt -gt 600 ]; then
        touch $MODDIR/disable &>/dev/null
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] $bootTimeCnt 开机超过10分钟未进入桌面, 已禁用冻它模块" >>$bootLogPath
        exit
    fi
}

# This function is copied from [ Uperf@yc9559 ] module.
wait_until_login() {

    # in case of /data encryption is disabled
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 5
        # handle_sec "开机动画(while sys.boot_completed==0)"
    done

    echo "[$(date "+%Y-%m-%d %H:%M:%S")] 进入Android" >>$bootLogPath

    # we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
    local test_file="/sdcard/Android/.PERMISSION_TEST_FREEZEIT"
    true >"$test_file"
    while [ ! -f "$test_file" ]; do
        sleep 2
        # handle_sec "等待进入桌面(wait to r/w sdcard)"
        true >"$test_file"
    done
    rm "$test_file"
}

mountFreezerV2() {
    for modDir in cgroupfix cgroupv1 cgroup_freezer_mount; do
        fullDir="/data/adb/modules/$modDir"
        if [[ -e $fullDir ]] && [[ ! -e $fullDir/disable ]]; then
            echo "模块[$(grep_prop name $fullDir/module.prop)]已启用, 存在冲突, 冻它已取消挂载FreezerV2操作。" >>$bootLogPath
            return
        fi
    done

    if [ -e /sys/fs/cgroup/uid_1000/cgroup.freeze ]; then
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 已支持FreezerV2(uid)" >>$bootLogPath
        return
    fi

    if [ -e /sys/fs/cgroup/frozen/cgroup.freeze ]; then
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 已支持FreezerV2(frozen)" >>$bootLogPath
        return
    fi

    # echo "[$(date "+%Y-%m-%d %H:%M:%S")] 开始卸载系统原生 cgroup/2" >>$bootLogPath

    umount /sys/fs/cgroup/freezer >/dev/null 2>&1
    umount /sys/fs/cgroup/unfrozen >/dev/null 2>&1
    umount /sys/fs/cgroup/frozen >/dev/null 2>&1
    umount /sys/fs/cgroup >>$bootLogPath 2>&1

    umount /dev/op_cgroup/freezer >/dev/null 2>&1
    umount /dev/op_cgroup >/dev/null 2>&1
    umount /dev/freezer >/dev/null 2>&1

    # umount /dev/cg2_bpf/unfrozen >/dev/null 2>&1
    # umount /dev/cg2_bpf/frozen >/dev/null 2>&1
    # umount /dev/cg2_bpf >/dev/null 2>&1

    mount -t cgroup2 -o nosuid,nodev,noexec none /sys/fs/cgroup >>$bootLogPath 2>&1
    echo "[$(date "+%Y-%m-%d %H:%M:%S")] 挂载 cgroup2" >>$bootLogPath
    sleep 1

    if [ -e /sys/fs/cgroup/uid_1000/cgroup.freeze ]; then
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 挂载已支持 FreezerV2(uid)" >>$bootLogPath
    else
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 挂载不支持 FreezerV2(uid)" >>$bootLogPath
    fi

    mkdir -p /sys/fs/cgroup/frozen
    mkdir -p /sys/fs/cgroup/unfrozen
    sleep 1

    if [[ -e /sys/fs/cgroup/frozen/cgroup.freeze ]] && [[ -e /sys/fs/cgroup/unfrozen/cgroup.freeze ]]; then
        echo 1 >/sys/fs/cgroup/frozen/cgroup.freeze
        echo 0 >/sys/fs/cgroup/unfrozen/cgroup.freeze
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 挂载已支持 FreezerV2(frozen)" >>$bootLogPath
    else
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 挂载不支持 FreezerV2(frozen)" >>$bootLogPath
    fi
}

echo "[$(date "+%Y-%m-%d %H:%M:%S")] 进入Linux" >$bootLogPath

if [[ -e $MODDIR/mount_v2 ]] && [[ $(cat $MODDIR/mount_v2) -eq "1" ]]; then
    androidVersion=$(getprop ro.build.version.release)
    if [[ $androidVersion -ge 11 ]] && [[ $androidVersion -le 13 ]]; then
        mountFreezerV2
    else
        echo "[$(date "+%Y-%m-%d %H:%M:%S")] 仅支持[Android 11-13]挂载FreezerV2, 当前[Android $androidVersion]" >>$bootLogPath
    fi
else
    echo "[$(date "+%Y-%m-%d %H:%M:%S")] 不挂载FreezerV2" >>$bootLogPath
fi

wait_until_login

echo "[$(date "+%Y-%m-%d %H:%M:%S")] 进入桌面, 准备启动冻它" >>$bootLogPath

rm -rf $MODDIR/fail_once

# 带一个任意参数将开启文件式日志 [ /sdcard/Android/freezeit.log ]
# $MODDIR/bin/freezeit 0
$MODDIR/bin/freezeit
