##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=true

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod
print_modname() {
	return
}

##########################################################################################
# Replace list
##########################################################################################
# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
SKIPUNZIP=0
REPLACE="
"
##########################################################################################
# Install
##########################################################################################
on_install() {
	$BOOTMODE || abort "
	!!! ONLY be installed on magisk. 
	!!! 仅支持在 Magisk 下安装, Recovery的老哥别手抖。
	"
    [ $API -ge 26 ] || abort "
	!!! ONLY support Android8.0 (SDK26) or above. 
	!!! 仅支持 安卓8.0 及以上版本，考虑一下换机吧。
	"
    [ $MAGISK_VER_CODE -ge 23000 ] || abort "
	!!! ONLY support Magisk V23.0 or above. 
	!!! 仅支持 Magisk V23.0 及以上版本。
	"
    [ $ARCH == "arm64" ] || abort "
	!!! ONLY support ARM64 platform. 
	!!! 仅支持 ARM 64位 平台。
	"
	
	unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
	unzip -o "$ZIPFILE" 'freezeit.conf' -d $TMPDIR  >&2

	module_id="$(grep_prop id $MODPATH/module.prop)"
	module_name="$(grep_prop name $MODPATH/module.prop)"
	module_version="$(grep_prop version $MODPATH/module.prop)"
	module_versionCode="$(grep_prop versionCode $MODPATH/module.prop)"
	module_versionCodeCompMin="$(grep_prop versionCodeCompMin $MODPATH/module.prop)"
	module_author="$(grep_prop author $MODPATH/module.prop)"
	module_logPath="$(grep_prop logPath $MODPATH/module.prop)"
	module_whiteListPath="$(grep_prop whiteListPath $MODPATH/module.prop)"
	module_crashPath="$(grep_prop crashPath $MODPATH/module.prop)"

	echo -e "\n********************************************"
	echo "  模块 Mod:  $module_name"
	echo "  识别 ID:   $module_id"
	echo "  版本 Ver:  $module_version"
	echo "  作者 Auth: $module_author"
	echo "  日志路径 LogPath:   $module_logPath"
	echo "  配置路径 WhiteList: $module_whiteListPath"
	echo "  崩溃路径 CrashPath: $module_crashPath"
	echo -e "********************************************\n"
	cat $MODPATH/changelog.txt
	echo -e "\n********************************************\n"

	WhiteListPath=$TMPDIR/freezeit.conf
	targetWhiteListPath=/sdcard/Android/freezeit.conf

	chmod 0777 WhiteListPath

	if [ -e $targetWhiteListPath ];then
		result=$(cat $targetWhiteListPath | grep "ListMode" )
		if [[ "$result" != "" ]];then
			rm $targetWhiteListPath
			cp $WhiteListPath $targetWhiteListPath
			echo "- 配置文件为初版，已移除并创建新版"
			echo "- The WhiteList is the original version. It has been removed and a new version created."
		else
			version=$(cat $targetWhiteListPath | grep "versionCode" | cut -d '=' -f 3)
			if [ $version -lt $module_versionCodeCompMin ];then
				mv -f $targetWhiteListPath ${targetWhiteListPath}.bak
				cp $WhiteListPath $targetWhiteListPath
				echo    "- 当前配置文件版本 Ver$version, 低于最低兼容版本 Ver$module_versionCodeCompMin"
				echo -e "- Current WhiteList Ver$version, less than minCompaVer Ver$module_versionCodeCompMin\n"
				echo    "- 配置文件已更新 Ver$module_versionCode, 旧配置文件备份为 ${targetWhiteListPath}.bak"
				echo -e "- WhiteList updated Ver$module_versionCode, Old WhiteList backed up as ${targetWhiteListPath}.bak\n"
			fi
		fi
	else
		cp $WhiteListPath $targetWhiteListPath
	fi
	echo -e ""\
	"- 配置文件路径 WhiteListPath:\n"\
	"  [ $targetWhiteListPath ]\n\n"\
	"- 若出现奔溃日志 请反馈给作者提升模块质量，谢谢。 酷安 @JARK006\n"\
	"- If there is a crash log, Please feed back to the\n"\
	"  author to improve module compatibility. Thanks!\n"\
	"  Email: jark006@qq.com\n"\
	"  [ $module_crashPath ]\n\n"\
	"- 安装完毕，若有配置需求，先去配置再重启。\n"\
	"- Done. If you need, edit WhiteList first\n"\
	"  and then restart.\n\n"
}

##########################################################################################
# Permissions
##########################################################################################
set_permissions() {
	# The following is default permissions, DO NOT remove
	set_perm_recursive $MODPATH  0  0  0755  0644
	set_perm_recursive $MODPATH/bin 0 0 0755 0755
}
