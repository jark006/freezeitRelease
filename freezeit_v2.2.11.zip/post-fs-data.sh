#!/system/bin/sh

# https://cs.android.com/android/platform/superproject/+/master:system/memory/lmkd/lmkd.cpp
# https://source.android.com/devices/tech/perf/lmkd
# setprop ro.lmk.use_minfree_levels true
# setprop ro.lmk.kill_heaviest_task true
# setprop ro.lmk.kill_timeout_ms 100
# setprop ro.lmk.use_psi false
# setprop ro.lmk.low 1001
# setprop ro.lmk.medium 1001
# setprop ro.lmk.critical 200
# setprop ro.lmk.upgrade_pressure 95
# setprop ro.lmk.downgrade_pressure 85
# setprop ro.lmk.swap_free_low_percentage 10
# setprop ro.lmk.critical_upgrade true

setprop persist.sys.gz.enable false
setprop persist.sys.powmillet.enable false
setprop persist.sys.brightmillet.enable false
