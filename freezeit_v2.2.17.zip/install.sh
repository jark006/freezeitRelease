##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=true

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod
print_modname() {
	return
}

##########################################################################################
# Replace list
##########################################################################################
# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
SKIPUNZIP=0
REPLACE="
"
##########################################################################################
# Install
##########################################################################################
on_install() {
	$BOOTMODE || abort "
	!!! ONLY be installed on magisk. 
	!!! 仅支持在 Magisk 下安装。
	"
	[ $API -ge 29 ] || abort "
	!!! ONLY support Android 10 (SDK29) or above. 
	!!! 仅支持 安卓10 或以上。
	"
	[ $ARCH == "arm64" ] || abort "
	!!! ONLY support ARM64 platform. 
	!!! 仅支持 ARM 64位 平台。
	"

	ORG_appcfg="/data/adb/modules/freezeit/appcfg.txt"
	BAK_appcfg="$TMPDIR/appcfg.txt"

	ORG_applabel="/data/adb/modules/freezeit/applabel.txt"
	BAK_applabel="$TMPDIR/applabel.txt"

	ORG_settings="/data/adb/modules/freezeit/settings.db"
	BAK_settings="$TMPDIR/settings.db"

	ORG_mount="/data/adb/modules/freezeit/mount_v2"
	BAK_mount="$TMPDIR/mount_v2"

	if [ -e $ORG_appcfg ]; then
		echo "- 开始备份配置文件"
		cp -f $ORG_appcfg $BAK_appcfg
	fi

	if [ -e $ORG_applabel ]; then
		echo "- 开始备份名称文件"
		cp -f $ORG_applabel $BAK_applabel
	fi

	if [ -e $ORG_settings ]; then
		echo "- 开始备份设置文件"
		cp -f $ORG_settings $BAK_settings
	fi

	if [ -e $ORG_mount ]; then
		echo "- 开始备份挂载识别文件"
		cp -f $ORG_mount $BAK_mount
	fi

	echo "- 开始释放模块文件"
	unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
	echo "- 释放完毕"

	if [ -e $BAK_appcfg ]; then
		echo "- 恢复配置文件"
		cp -f $BAK_appcfg $MODPATH/appcfg.txt
	fi

	if [ -e $BAK_applabel ]; then
		echo "- 恢复名称文件"
		cp -f $BAK_applabel $MODPATH/applabel.txt
	fi

	if [ -e $BAK_settings ]; then
		echo "- 恢复设置文件"
		cp -f $BAK_settings $MODPATH/settings.db
	fi

	if [ -e $BAK_mount ]; then
		echo "- 恢复挂载识别文件"
		cp -f $BAK_mount $MODPATH/mount_v2
	fi

	module_id="$(grep_prop id $MODPATH/module.prop)"
	module_name="$(grep_prop name $MODPATH/module.prop)"
	module_version="$(grep_prop version $MODPATH/module.prop)"
	module_author="$(grep_prop author $MODPATH/module.prop)"

	echo -e "\n********************************************"
	echo "  模块 Mod:  $module_name"
	echo "  识别  ID:  $module_id"
	echo "  版本 Ver:  $module_version"
	echo "  作者 Auh:  $module_author"
	echo -e "********************************************\n"

	output=$(pm uninstall cn.myflv.android.noanr)
	if [ $output == "Success" ]; then
		echo "- 卸载 [NoANR] 成功，功能冲突"
	fi

	output=$(pm list packages cn.myflv.android.noactive)
	if [ ${#output} -gt 2 ]; then
		echo "- !!! 检测到 [NoActive](myflavor), 功能重复且冲突, 请手动禁用或卸载"
	fi

	output=$(pm list packages com.github.f19f.milletts)
	if [ ${#output} -gt 2 ]; then
		echo "- !!! 检测到 [MiTombstone](f19没有新欢), 功能重复且冲突, 请手动禁用或卸载"
	fi

	if [ -e "/data/adb/modules/mubei" ]; then
		echo "- !!! 检测到 [自动墓碑后台](奋斗的小青年), 功能重复且冲突, 已禁用, 有需要需自行开启"
		touch /data/adb/modules/mubei/disable
	fi

	if [ -e "/data/adb/modules/Hc_tombstone" ]; then
		echo "- !!! 检测到 [新内核墓碑](时雨星空/火柴), 功能重复且冲突, 已禁用, 有需要需自行开启"
		touch /data/adb/modules/Hc_tombstone/disable
	fi

	apkPath_ORG=$(ls $MODPATH/freezeit*.apk)
	apkPath="/data/local/tmp/freezeit.apk"
	cp -f $apkPath_ORG $apkPath
	chmod 666 $apkPath

	echo "- 正在安装 冻它APP..."
	output=$(pm install -r -f $apkPath)
	if [ $output == "Success" ]; then
		echo "- 冻它APP 安装成功"
	else
		echo -e "- !!!\n- !!!  冻它APP 安装失败: [$output]\n- !!!\n"
		apkPathSdcard="/sdcard/freezeit_${module_version}.apk"
		cp -f $apkPath $apkPathSdcard
		echo -e "- 请手动安装 冻它APK [ $apkPathSdcard ]\n"
	fi
	rm -rf $apkPath

	# system.prop 仅限安卓 10 ~ 15
	androidVersion=$(getprop ro.build.version.release)
	if [ $androidVersion -ge 10 -a $androidVersion -le 15 ]; then
		echo "
ro.lmk.swap_free_low_percentage=10
ro.lmk.psi_partial_stall_ms=200
ro.lmk.psi_complete_stall_ms=700" >>$MODPATH/system.prop
	fi

	# 仅限 MIUI 13
	MIUI_VersionCode=$(getprop ro.miui.ui.version.code)
	if [ $MIUI_VersionCode -eq 13 ]; then
		echo "
persist.sys.gz.enable=false
persist.sys.millet.handshake=false
persist.sys.powmillet.enable=false
persist.sys.brightmillet.enable=false" >>$MODPATH/system.prop
	fi

	echo -e \
		"- 模块安装完毕，重启生效。\n\n" \
		"- 若出现异常日志 请反馈给作者，谢谢。酷安 @JARK006\n" \
		"  [ /sdcard/Android/freezeit_crash_log.txt ]\n"
}

##########################################################################################
# Permissions
##########################################################################################
set_permissions() {
	# The following is default permissions, DO NOT remove
	set_perm_recursive $MODPATH 0 0 0755 0644
	set_perm_recursive $MODPATH/bin 0 0 0755 0755
}
